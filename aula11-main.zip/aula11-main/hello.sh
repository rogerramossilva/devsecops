#!/bin/sh
echo "Hello from a signed image!"

