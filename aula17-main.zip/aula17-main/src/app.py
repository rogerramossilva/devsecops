def hello():
    password = "123456"  
    token = "AKIAIOSFODNN7EXAMPLE" 
    print("Hello, world!")

