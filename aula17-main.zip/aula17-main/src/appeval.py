def safe_function():
    print("Isso é seguro!")

def unsafe_function(user_input):
    eval(user_input)  # Aqui está o uso perigoso de eval

unsafe_function("print('Teste de código malicioso')")

