#!/bin/bash
#import.sh
mysql -uroot -p12345678 backup  < /tmp/backup.sql