	<div id="grid_footer">
		<div class="grid_footer_center">	
			<p>&copy;2017 Allsafe Cybersecurity - Todos os direitos reservados.</p>
		</div>
	</div>

</body>
</html>
