import subprocess
import hashlib

def run_command(cmd):
    # Vulnerabilidade: uso de shell=True pode causar command injection
    subprocess.call(cmd, shell=True)

def insecure_hash(data):
    # Vulnerabilidade: uso de MD5 para hashing
    return hashlib.md5(data.encode()).hexdigest()

def main():
    run_command("ls -la")
    print(insecure_hash("my_password"))

if __name__ == "__main__":
    main()
