from flask import Flask, jsonify
from middleware import require_role
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Limiter (Rate-Limiting por IP)
limiter = Limiter(key_func=get_remote_address, app=app)

@app.route("/users")
@limiter.limit("5 per minute")  # Limite de 5 requisições por minuto
@require_role("admin")          # Apenas admin pode acessar
def get_users():
    return jsonify(["maria", "joao", "ana"])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)

