import hvac
import os

VAULT_ADDR = os.getenv("VAULT_ADDR", "http://127.0.0.1:8200")
ROLE_ID = os.getenv("ROLE_ID")
SECRET_ID = os.getenv("SECRET_ID")

# Inicializar cliente sem token
client = hvac.Client(url=VAULT_ADDR)

# Autenticar via AppRole e obter token temporário
login_response = client.auth.approle.login(
    role_id=ROLE_ID,
    secret_id=SECRET_ID
)
client.token = login_response["auth"]["client_token"]

# Validar autenticação
if not client.is_authenticated():
    raise Exception("❌ Falha na autenticação com Vault via AppRole")

# Ler segredo do KV engine V2
secret = client.secrets.kv.v2.read_secret_version(path="ci/app/db", raise_on_deleted_version=True, mount_point="secret")

db_user = secret["data"]["data"]["user"]
db_pass = secret["data"]["data"]["password"]

print(f"✅ Usuário do banco: {db_user}")
print(f"✅ Senha do banco: {db_pass}")
print(f"Conectando ao banco com user={db_user} e password={db_pass}")
