package lab;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);
    public static void main(String[] args) throws Exception {
        System.out.println("Hello from vulnerable Log4j app!");
        // Log untrusted input on purpose
        String user = args.length > 0 ? args[0] : "${jndi:ldap://example.com/a}";
        logger.error("User provided: " + user);
        Thread.sleep(1000);
    }
}
