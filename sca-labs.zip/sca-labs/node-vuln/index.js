const express = require('express');
const _ = require('lodash');
const minimist = require('minimist');
const serialize = require('serialize-javascript');

const app = express();

app.get('/', (req, res) => {
  res.send('Hello from vulnerable Node.js app! lodash version: ' + _.VERSION);
});

app.get('/echo', (req, res) => {
  // Intentionally naive serialization (XSS risks with old serialize-javascript)
  const q = minimist(process.argv.slice(2));
  res.send(serialize({query: req.query, args: q}));
});

app.listen(3000, () => console.log('Listening on 3000'));
