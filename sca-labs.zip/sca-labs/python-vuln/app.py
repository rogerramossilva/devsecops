from flask import Flask, request
import yaml  # Unsafe loader on purpose

app = Flask(__name__)

@app.route("/")
def index():
    return "Hello from vulnerable Flask!"

@app.route("/yaml", methods=["POST"])
def yaml_load():
    # Intentionally unsafe: yaml.load without SafeLoader
    content = request.data.decode("utf-8")
    data = yaml.load(content)  # DO NOT DO THIS IN REAL APPS
    return {"parsed": data}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
